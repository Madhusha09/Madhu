package com.niit.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.*;

@Repository("ProductDao")
public class ProductDao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public ProductDao(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void insert(com.niit.model.Product ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Product Inserted");
	}
	
	@Transactional
	public void delete(int pid)
	{
			Product ob=(Product)sessionFactory.getCurrentSession().load(Product.class,pid);
			sessionFactory.getCurrentSession().delete(ob);
			System.out.println("Product gets Deleted");
	}
	
	@Transactional
	public List<Product> retrieve()
	{
		Query q=sessionFactory.getCurrentSession().createQuery("from Product");
				List<Product>ob = (List<Product>)q.list();
				return ob;
		
	}
	
	@Transactional
	public Product getProductData(int pid)
	{
		return (Product)sessionFactory.getCurrentSession().get(Product.class,pid);
	}

	@Transactional
	public void updateProduct(com.niit.model.Product ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Product Updated");
	}

}