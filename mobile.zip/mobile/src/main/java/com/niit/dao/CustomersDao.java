package com.niit.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.*;

@Repository("CustomersDao")

public class CustomersDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public CustomersDao(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void insert(com.niit.model.Customers ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Customers Inserted");
	}
	
	@Transactional
	public void delete(int cid)
	{
			Customers ob=(Customers)sessionFactory.getCurrentSession().load(Customers.class,cid);
			sessionFactory.getCurrentSession().delete(ob);
			System.out.println("Customers gets Deleted");
	}
	
	@Transactional
	public List<Customers> retrieve()
	{
		Query q=sessionFactory.getCurrentSession().createQuery("from Customers");
		List<Customers>ob=(List<Customers>)q.list();
		return ob;
	}
	
	@Transactional
	public Customers getCustomersData(int cid)
	{
		return (Customers)sessionFactory.getCurrentSession().get(Customers.class,cid);
	}

	@Transactional
	public void updateCustomers(com.niit.model.Customers ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Customers Updated");
	}

}
