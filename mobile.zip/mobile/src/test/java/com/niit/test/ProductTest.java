package com.niit.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.model.*;
import com.niit.dao.*;

public class ProductTest 
{
	private static AnnotationConfigApplicationContext context;

	public static void main(String arg[])
	{
	context = new AnnotationConfigApplicationContext();
	
				context.scan("com.niit.test");
				context.refresh();
				
				
				Product prdt1=new Product();
				prdt1.setPid(1004);
				prdt1.setCid(1001);
				prdt1.setSid(1001);
				prdt1.setProdname("Redmi Note 3");
				prdt1.setStock(10);
				prdt1.setPrice(10000);
				

				//==========Creating DAO Object
				ProductDao pdao=(ProductDao)context.getBean("productDao");
				
				//==========Test for Inserting Product Bean
				pdao.insert(prdt1);
				
				//============Test for Deleting Product Bean
				
				pdao.delete(1002);
				
				//============Test for Retrieving the Product Beans
				
				List<Product> prodlist=pdao.retrieve();
				
				for(Product p:prodlist)
				{
					System.out.println(p.getPid()+"   "+p.getProdname()+"   ");
				}
				
				System.out.println("==========================================");
				
				//============Test for Getting a Particular Product Bean
				
				Product prdt=pdao.getProductData(1004);
				System.out.println("Product Name:"+prdt.getProdname());
				
				System.out.println("Price:"+prdt.getPrice());
				System.out.println("==================Updating To===============");
			
				prdt.setPrice(12000);
				
				//==========Test for Updating a Particular Product Bean
				pdao.updateProduct(prdt);
				
				
				
	}
    
}

