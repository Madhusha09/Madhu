package com.niit.test;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.model.*;
import com.niit.dao.*;

public class CustomersTest {
	public static void main(String arg[])
	{
				AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
				context.scan("com.niit");
				context.refresh();
				
				
				Customers cus1=new Customers();
				cus1.setCid(1004);
				cus1.setName("Redmi Note 3");
				cus1.setUsername("kasthu");
				cus1.setPassword("10000");
				cus1.setAddress("Chennai");
				cus1.setPhone("12345");
			

				//==========Creating DAO Object
			CustomersDao cdao=(CustomersDao)context.getBean("CustomersDao");
				
				//==========Test for Inserting Product Bean
				cdao.insert(cus1);
				
				//============Test for Deleting Product Bean
				
				cdao.delete(1004);
				
				//============Test for Retrieving the Product Beans
				
				List<Customers> cuslist=cdao.retrieve();
				for(Customers c1:cuslist)
				{
					System.out.println(c1.getCid()+"   "+c1.getName()+"   "+c1.getUsername()+"  "+c1.getPassword()+"  "+c1.getAddress()+"  "+c1.getPhone()+"  ");
				}
				
				System.out.println("==========================================");
				
				//============Test for Getting a Particular Product Bean
				
				Customers cus=cdao.getCustomersData(1004);
				System.out.println("Customers Name:"+cus.getName());
				System.out.println("Customers Username:"+cus.getUsername());
				System.out.println("Customers Pasword:"+cus.getPassword());
				System.out.println("Customers Address:"+cus.getAddress());
				System.out.println("Customers Phone:"+cus.getPhone());
				
		
				System.out.println("==================Updating To===============");
				
				cus.setAddress("Bangalore");
				
				//==========Test for Updating a Particular Product Bean
				cdao.updateCustomers(cus);
				
				
	}				

}
