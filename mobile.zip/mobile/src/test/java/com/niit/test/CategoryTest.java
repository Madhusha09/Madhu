package com.niit.test;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.model.*;
import com.niit.dao.*;
public class CategoryTest {
	public static void main(String arg[])
	
		{
					AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
					context.scan("com.niit");
					context.refresh();
					
					
					Category ctg1=new Category();
					ctg1.setCid(1002);
			        ctg1.setCname("4G Mobile");
			      //==========Creating DAO Object
					CategoryDao cdao1=(CategoryDao)context.getBean("CategoryDao");
					
					//==========Test for Inserting Product Bean
					cdao1.insert(ctg1);
					
					//============Test for Deleting Product Bean
					
					cdao1.delete(1002);
					
					//============Test for Retrieving the Product Beans
					
					List<Category> ctglist=cdao1.retrieve();
					
					for(Category c:ctglist)
					{
						System.out.println(c.getCid()+"   "+c.getCname()+"   ");
					}
					
					System.out.println("==========================================");
					
					//============Test for Getting a Particular Product Bean
					
					Category ctg=cdao1.getCategoryData(1002);
					System.out.println("Category Name:"+ctg.getCname());
					
					
					System.out.println("==================Updating To===============");
					
			         ctg.setCname("3G Mobile");
			
					
					//==========Test for Updating a Particular Product Bean
					cdao1.updateCategory(ctg);
					
					
					
		}
					
}
